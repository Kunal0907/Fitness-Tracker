package com.fitness_tracker.service;

import java.util.Date;
import java.util.List;

import com.fitness_tracker.entity.Workout;

public interface IWorkoutService {

	// add workout in application
	Workout addWorkout(Workout workout);

	// read all workouts
	List<Workout> readAllWorkouts();

	// read single workout by date
	Workout readSingleWorkout(String workoutName);

	// update workout by its ID
	Workout updateWorkout(Integer workoutId, Workout workout);

	// delete a workout by its ID
	String deleteWorkout(Integer workoutId);
}
