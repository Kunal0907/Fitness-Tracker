package com.fitness_tracker.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fitness_tracker.entity.Workout;

public interface WorkoutRepository extends JpaRepository<Workout, Integer> {

	Optional<Workout> findByWorkoutName(String workoutName);

	Optional<Workout> findByWorkoutId(Integer workoutId);

}
