package com.fitness_tracker.exception;


public class WorkoutNotFoundException extends RuntimeException {
	
	public WorkoutNotFoundException(String message) {
		super(message);
	}

	public WorkoutNotFoundException(Integer workoutId) {
		super();
	}

}
