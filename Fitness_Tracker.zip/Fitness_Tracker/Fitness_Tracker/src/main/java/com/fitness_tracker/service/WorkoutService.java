package com.fitness_tracker.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fitness_tracker.dao.WorkoutRepository;
import com.fitness_tracker.entity.Workout;
import com.fitness_tracker.exception.WorkoutNotFoundException;

@Service
public class WorkoutService implements IWorkoutService {

	@Autowired
	private WorkoutRepository workoutRepository;

	@Override
	public Workout addWorkout(Workout workout) {
		Workout add = workoutRepository.save(workout);
		return add;
	}

	@Override
	public List<Workout> readAllWorkouts() {
		List<Workout> readAll = workoutRepository.findAll();
		return readAll;
	}

	@Override
	public Workout readSingleWorkout(String workoutName) {
		Workout readOne = workoutRepository.findByWorkoutName(workoutName)
				.orElseThrow(() -> new WorkoutNotFoundException(workoutName));
		return readOne;
	}

	@Override
	public Workout updateWorkout(Integer workoutId, Workout workout) {
		Workout updateWorkout = workoutRepository.findByWorkoutId(workoutId)
				.orElseThrow(() -> new WorkoutNotFoundException(workoutId));
		updateWorkout.setWorkoutName(workout.getWorkoutName());
		updateWorkout.setDuration(workout.getDuration());
		updateWorkout.setCaloriesBurned(workout.getCaloriesBurned());
		updateWorkout.setDate(workout.getDate());

		Workout updatedWorkout = workoutRepository.save(updateWorkout);
		return updatedWorkout;
	}

	@Override
	public String deleteWorkout(Integer workoutId) {
		Workout deleteWorkout = workoutRepository.findByWorkoutId(workoutId)
				.orElseThrow(() -> new WorkoutNotFoundException(workoutId));
		workoutRepository.delete(deleteWorkout);
		return "Workout with given ID : " + workoutId + " has been deleted...";
	}

}
