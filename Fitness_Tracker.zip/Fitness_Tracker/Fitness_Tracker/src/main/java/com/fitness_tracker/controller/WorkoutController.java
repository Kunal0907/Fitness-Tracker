package com.fitness_tracker.controller;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fitness_tracker.entity.Workout;
import com.fitness_tracker.service.WorkoutService;

@RestController
@RequestMapping("/fitness")
public class WorkoutController {

	@Autowired
	private WorkoutService workoutService;

	@PostMapping("/add")
	public ResponseEntity<?> addWorkout(@RequestBody Workout workout) {
		try {
			Workout addWorkout = workoutService.addWorkout(workout);
			return new ResponseEntity<>(addWorkout, HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping("/readall")
	public ResponseEntity<?> readWorkout() {
		try {
			Collection<Workout> readAllWorkout = workoutService.readAllWorkouts();
			return new ResponseEntity<>(readAllWorkout, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping("/readone/{workoutName}")
	public ResponseEntity<?> readOneWorkout(@PathVariable String workoutName) {
		try {
			Workout readOneWorkout = workoutService.readSingleWorkout(workoutName);
			return new ResponseEntity<>(readOneWorkout, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PutMapping("/update/{workoutId}")
	public ResponseEntity<?> updateWorkout(@PathVariable Integer workoutId, @RequestBody Workout workout) {
		try {
			Workout readOneWorkout = workoutService.updateWorkout(workoutId, workout);
			return new ResponseEntity<>(readOneWorkout, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@DeleteMapping("/delete/{workoutId}")
	public ResponseEntity<?> deleteWorkout(@PathVariable Integer workoutId) {
		try {
			String readOneWorkout = workoutService.deleteWorkout(workoutId);
			return new ResponseEntity<>(readOneWorkout, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
